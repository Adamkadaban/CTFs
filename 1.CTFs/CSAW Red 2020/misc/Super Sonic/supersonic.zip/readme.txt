Note to self: If I ever want to get that password, I'll have to face the music.
